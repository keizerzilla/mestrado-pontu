/**
 * @file char-ext.c
 * @author Artur Rodrigues Rocha Neto
 * @date 2017
 * @brief Utilitário extrator de múltiplos momentos invariantes
 */

#include "include/extraction.h"

int main(int argc, char** argv)
{
    return program_interface(argc, argv);
}

