/**
 * @file centerprofile.c
 * @author Artur Rodrigues Rocha Neto
 * @date 2018
 * @brief Utilitário extrator de perfil normal
 */

#include "include/extraction.h"

int main(int argc, char** argv)
{
    return center_profile(argc, argv);
}

