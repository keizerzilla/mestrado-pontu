#!/bin/bash

# EXTRACAO
./feature-extraction.sh

# CLASSIFICACAO
./classification.sh
